// ENVIRONMENTAL POLLUTION TRACKER
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>

using namespace std;
void pause();

// ===== CLASS DECLARATIONS =====

enum Severity { LOW, MEDIUM, HIGH };

class Pollution {
public:
  int id;
  string country;
  string city;
  string location;
  string pollutionType;
  float value;
  string unit;
  string date;
  bool isSafe;
  Severity severity;
  float previousValue;
  string trend;
  string lastUpdated;

public:
  Pollution();
  Pollution(int id, string country, string city, string loc, string type,
            float val, string u, string d);
  int getId();
  string getCountry();
  string getCity();
  string getLocation();
  string getType();
  float getValue();
  string getUnit();
  string getDate();
  bool getSafeStatus();
  Severity getSeverity();
  string getSeverityString();
  void setId(int id);
  void setCountry(string c);
  void setCity(string c);
  void setLocation(string loc);
  void setType(string type);
  void setValue(float val);
  void setUnit(string u);
  void setDate(string d);
  void setSafeStatus(bool status);
  void display();
  string toString();
  void checkSafetyLimits();
  void calculateSeverity();
  string classifyRisk();
  bool shouldGenerateAlert();
  void updateTrend();
  void setPreviousValue(float val);
  float getPreviousValue();
  string getTrend();
  string getLastUpdated();
  void setLastUpdated(string time);
  static bool isValidType(string type);
  static bool isValidValue(string type, float value);
  static bool isValidString(string str, int maxLen);
};

class PollutionNode {
public:
  Pollution data;
  PollutionNode *next;
  PollutionNode(Pollution p) {
    data = p;
    next = NULL;
  }
};

class PollutionList {
public:
  PollutionNode *head;
  int count;

public:
  PollutionList();
  ~PollutionList();
  void addPollution(Pollution p);
  void displayAll();
  void displayByType(string type);
  void displayByLocation(string location);
  Pollution *searchById(int id);
  void sortByValue();
  void deleteById(int id);
  int getCount();
  PollutionNode *getHead();
  void generateReport();
  void trendAnalysis();
  void predictPollution();
  bool isIdUnique(int id);
  void checkSafetyAlerts();
  void updatePollutionValue(int id, float newValue);
  void displayAveragePollutionPerArea();
  int countUnsafeRecords();
  void displayAreaRiskReport();
  void displayTrendReport();
  void displaySeverityDistribution();
};

class Complaint {
public:
  int complaintId;
  string citizenName;
  string location;
  string pollutionType;
  string description;
  string date;
  string status;
  int linkedPollutionId;
  string priority;

public:
  Complaint();
  Complaint(int id, string name, string loc, string type, string desc,
            string d);
  int getId();
  string getCitizenName();
  string getLocation();
  string getPollutionType();
  string getDescription();
  string getDate();
  string getStatus();
  void setId(int id);
  void setCitizenName(string name);
  void setLocation(string loc);
  void setPollutionType(string type);
  void setDescription(string desc);
  void setDate(string d);
  void setStatus(string status);
  void display();
  string toString();
  void linkToPollution(int pollutionId);
  void escalate();
  bool isLinked();
  int getLinkedPollutionId();
  string getPriority();
  void setPriority(string p);
  static bool isValidPollutionType(string type);
  static bool isValidDate(string date);
  static bool isValidStatus(string status);
  static bool isValidName(string name);
  static bool isValidLocation(string location);
};

class ComplaintNode {
public:
  Complaint data;
  ComplaintNode *next;
  ComplaintNode(Complaint c) {
    data = c;
    next = NULL;
  }
};

class ComplaintList {
public:
  ComplaintNode *head;
  int count;

public:
  ComplaintList();
  ~ComplaintList();
  void addComplaint(Complaint c);
  void displayAll();
  void displayPending();
  void displayResolved();
  Complaint *searchById(int id);
  void updateStatus(int id, string newStatus);
  void deleteComplaint(int id);
  int getCount();
  ComplaintNode *getHead();
  void sortByDate();
  void displayByType(string type);
  void displayByLocation(string location);
  void resolveComplaint(int id);
  void displayResolutionStats();
  void displayTypeDistribution();
  bool isIdUnique(int id);
  void calculateAutoPriority();
};

class Sensor {
public:
  int sensorId;
  string sensorType;
  string location;
  bool isActive;
  float lastReading;
  int faultCount;

public:
  Sensor();
  Sensor(int id, string type, string loc);
  int getId();
  string getType();
  string getLocation();
  bool getStatus();
  float getLastReading();
  void setId(int id);
  void setType(string type);
  void setLocation(string loc);
  void setStatus(bool status);
  void setLastReading(float reading);
  float generateReading();
  void display();
  bool isFaulty();
  void incrementFaultCount();
  void resetFaultCount();
  bool shouldDeactivate();
  int getFaultCount();
  static bool isValidType(string type);
  static bool isValidString(string str, int maxLen);
};

class QueueNode {
public:
  Sensor data;
  QueueNode *next;
  QueueNode(Sensor s) {
    data = s;
    next = NULL;
  }
};

class SensorQueue {
public:
  QueueNode *front;
  QueueNode *rear;
  int size;

public:
  SensorQueue();
  ~SensorQueue();
  void enqueue(Sensor s);
  Sensor dequeue();
  bool isEmpty();
  int getSize();
  void displayQueue();
  void processAllSensors();
};

class SensorArray {
public:
  float readings[100];
  int count;

public:
  SensorArray();
  void addReading(float reading);
  void displayReadings();
  float getAverage();
  float getMax();
  float getMin();
  void clearReadings();
};

class SensorManager {
public:
  Sensor sensors[50];
  int sensorCount;

public:
  SensorManager();
  void addSensor(Sensor s);
  void displayAllSensors();
  void displayActiveSensors();
  void displayInactiveSensors();
  Sensor *findSensorById(int id);
  void toggleSensorStatus(int id);
  void manualDataEntry();
  void simulateAllReadings();
  int getSensorCount();
  void deactivateFaultySensors();
  void resetSensorHealth(int id);
  void emergencyShutdownByArea(string area);
  int countActiveInArea(string area);
  int countFaultySensors();
  bool isNameUnique(string name, string location);
  void deleteSensor(int id);
};

using namespace std;

class Pollution;
class Complaint;

class Operation {
public:
  string operationType;
  int recordId;
  string details;
  string timestamp;

  Pollution *deletedPollution;
  Complaint *deletedComplaint;

  Operation() {
    operationType = "";
    recordId = 0;
    details = "";
    timestamp = "";
    deletedPollution = NULL;
    deletedComplaint = NULL;
  }

  Operation(string type, int id, string det, string time) {
    operationType = type;
    recordId = id;
    details = det;
    timestamp = time;
    deletedPollution = NULL;
    deletedComplaint = NULL;
  }

  void display() {
    cout << "Operation: " << operationType << endl;
    cout << "Record ID: " << recordId << endl;
    cout << "Details: " << details << endl;
    cout << "Time: " << timestamp << endl;
  }
};

class StackNode {
public:
  Operation data;
  StackNode *next;

  StackNode(Operation op) {
    data = op;
    next = NULL;
  }
};

class UndoStack {
private:
  StackNode *top;
  int size;
  int maxSize;

public:
  UndoStack();
  UndoStack(int max);
  ~UndoStack();

  void push(Operation op);
  Operation pop();
  Operation peek();
  bool isEmpty();
  bool isFull();
  int getSize();
  void displayStack();
  void clear();
};

using namespace std;

class TreeNode {
public:
  string name;
  string type;
  int level;
  TreeNode *children[10];
  int childCount;
  TreeNode *parent;

  TreeNode(string n, string t, int l) {
    name = n;
    type = t;
    level = l;
    childCount = 0;
    parent = NULL;
    for (int i = 0; i < 10; i++) {
      children[i] = NULL;
    }
  }
};

class AreaTree {
private:
  TreeNode *root;
  void saveTreeHelper(TreeNode *node, ofstream &file, int indent);

public:
  AreaTree();
  ~AreaTree();

  void createRoot(string countryName);
  void addCity(string cityName);
  void addArea(string cityName, string areaName);
  void addSensor(string cityName, string areaName, string sensorName,
                 string sensorType);

  void displayTree();
  void displayTreeHelper(TreeNode *node, int indent);
  void displayCities();
  void displayAreas(string cityName);
  void displaySensors(string cityName, string areaName);

  TreeNode *findCity(string cityName);
  TreeNode *findArea(string cityName, string areaName);
  TreeNode *findSensor(string cityName, string areaName, string sensorName);

  int getTotalNodes();
  int countNodesHelper(TreeNode *node);
  void displayPath(string cityName, string areaName);
  TreeNode *getRoot();

  void saveTreeToFile(string filename);
  void loadTreeFromFile(string filename);

  static bool isValidString(string str, int maxLen);
};

using namespace std;

#define MAX_AREAS 20

class Area {
public:
  int id;
  string name;
  float pollutionLevel;

  Area() {
    id = 0;
    name = "";
    pollutionLevel = 0.0;
  }

  Area(int i, string n, float p) {
    id = i;
    name = n;
    pollutionLevel = p;
  }
};

class PollutionGraph {
private:
  Area areas[MAX_AREAS];
  int adjacencyMatrix[MAX_AREAS][MAX_AREAS];
  int areaCount;

public:
  PollutionGraph();

  void addArea(string name, float pollutionLevel);
  void addConnection(int area1, int area2);

  void displayAreas();
  void displayConnections();
  void displayAdjacencyMatrix();

  int findAreaByName(string name);
  void displayNeighbors(int areaId);

  void analyzePollutionSpread(int sourceArea);
  void findHighlyPollutedAreas();

  int getAreaCount();
  bool areaExists(int areaId);
  bool connectionExists(int area1, int area2);
  void syncAreasFromTree(class AreaTree &tree, class PollutionList &pList);
};

class FileHandler {
public:
  FileHandler();
  void loadPollutionData(class PollutionList &pl);
  void loadComplaintData(class ComplaintList &cl);
  void loadSensorData(class SensorManager &sm);
  void savePollutionData(class PollutionList &pl);
  void saveComplaintData(class ComplaintList &cl);
  void saveSensorData(class SensorManager &sm);
  void createBackup();
  bool fileExists(string filename);

private:
  string pollutionFile;
  string complaintFile;
  string sensorFile;
};

// ===== IMPLEMENTATIONS =====

Pollution::Pollution() {
  id = 0;
  country = "";
  city = "";
  location = "";
  pollutionType = "";
  value = 0.0;
  unit = "";
  date = "";
  isSafe = true;
  severity = LOW;
  previousValue = 0.0;
  trend = "Stable";
  lastUpdated = "";
}

Pollution::Pollution(int id, string country, string city, string loc,
                     string type, float val, string u, string d) {
  this->id = id;
  this->country = country;
  this->city = city;
  this->location = loc;
  this->pollutionType = type;
  this->value = val;
  this->unit = u;
  this->date = d;
  this->previousValue = 0.0;
  this->trend = "New";
  this->lastUpdated = d;
  checkSafetyLimits();
  calculateSeverity();
}

int Pollution::getId() { return id; }
string Pollution::getCountry() { return country; }
string Pollution::getCity() { return city; }
string Pollution::getType() { return pollutionType; }
string Pollution::getLocation() { return location; }
float Pollution::getValue() { return value; }
string Pollution::getUnit() { return unit; }
string Pollution::getDate() { return date; }
bool Pollution::getSafeStatus() { return isSafe; }
Severity Pollution::getSeverity() { return severity; }

string Pollution::getSeverityString() {
  if (severity == LOW)
    return "LOW";
  if (severity == MEDIUM)
    return "MEDIUM";
  return "HIGH";
}

void Pollution::setId(int id) { this->id = id; }
void Pollution::setCountry(string c) { this->country = c; }
void Pollution::setCity(string c) { this->city = c; }
void Pollution::setType(string type) { this->pollutionType = type; }
void Pollution::setLocation(string loc) { this->location = loc; }
void Pollution::setValue(float val) {
  this->value = val;
  checkSafetyLimits();
  calculateSeverity();
}
void Pollution::setUnit(string u) { this->unit = u; }
void Pollution::setDate(string d) { this->date = d; }
void Pollution::setSafeStatus(bool status) { this->isSafe = status; }

void Pollution::checkSafetyLimits() {
  if (pollutionType == "Air") {
    if (value > 100)
      isSafe = false;
    else
      isSafe = true;
  } else if (pollutionType == "Water") {
    if (value < 6.5 || value > 8.5)
      isSafe = false;
    else
      isSafe = true;
  } else if (pollutionType == "Soil") {
    if (value > 50)
      isSafe = false;
    else
      isSafe = true;
  } else if (pollutionType == "Noise") {
    if (value > 85)
      isSafe = false;
    else
      isSafe = true;
  }
}

void Pollution::calculateSeverity() {
  float safeLimit = 0;

  if (pollutionType == "Air") {
    safeLimit = 100;
  } else if (pollutionType == "Water") {
    if (value >= 6.5 && value <= 8.5) {
      severity = LOW;
      return;
    }
    safeLimit = 8.5;
  } else if (pollutionType == "Soil") {
    safeLimit = 50;
  } else if (pollutionType == "Noise") {
    safeLimit = 85;
  }

  if (value <= safeLimit) {
    severity = LOW;
  } else if (value <= safeLimit * 2) {
    severity = MEDIUM;
  } else {
    severity = HIGH;
  }
}

void Pollution::display() {
  cout << "\n--- Pollution Record ---" << endl;
  cout << "ID: " << id << endl;
  cout << "Country: " << country << endl;
  cout << "City: " << city << endl;
  cout << "Location: " << location << endl;
  cout << "Type: " << pollutionType << endl;
  cout << "Value: " << value << " " << unit << endl;
  cout << "Date: " << date << endl;
  cout << "Status: " << (isSafe ? "SAFE" : "UNSAFE - WARNING!") << endl;
  cout << "Severity: " << getSeverityString() << endl;
  cout << "------------------------" << endl;
}

string Pollution::toString() {
  return to_string(id) + "," + country + "," + city + "," + location + "," +
         pollutionType + "," + to_string(value) + "," + unit + "," + date +
         "," + (isSafe ? "1" : "0");
}

bool Pollution::isValidType(string type) {
  return (type == "Air" || type == "Water" || type == "Soil" ||
          type == "Noise");
}

bool Pollution::isValidValue(string type, float value) {
  if (value < 0)
    return false;
  if (type == "Air" && value > 500)
    return false;
  if (type == "Water" && value > 14)
    return false;
  if (type == "Soil" && value > 100)
    return false;
  if (type == "Noise" && value > 150)
    return false;
  return true;
}

bool Pollution::isValidString(string str, int maxLen) {
  if (str.length() == 0 || str.length() > maxLen)
    return false;
  return true;
}

PollutionList::PollutionList() {
  head = NULL;
  count = 0;
}

PollutionList::~PollutionList() {
  PollutionNode *current = head;
  while (current != NULL) {
    PollutionNode *temp = current;
    current = current->next;
    delete temp;
  }
}

void PollutionList::addPollution(Pollution p) {
  if (!isIdUnique(p.getId())) {
    cout << "\nError: ID already exists!" << endl;
    return;
  }

  if (!Pollution::isValidType(p.getType())) {
    cout << "\nError: Invalid type! Use Air/Water/Soil/Noise" << endl;
    return;
  }

  if (!Pollution::isValidValue(p.getType(), p.getValue())) {
    cout << "\nError: Value out of range!" << endl;
    return;
  }

  if (!Pollution::isValidString(p.getLocation(), 50)) {
    cout << "\nError: Location invalid (max 50 chars)!" << endl;
    return;
  }

  PollutionNode *newNode = new PollutionNode(p);

  if (head == NULL) {
    head = newNode;
  } else {
    PollutionNode *temp = head;
    while (temp->next != NULL) {
      temp = temp->next;
    }
    temp->next = newNode;
  }
  count++;
  cout << "\nPollution record added successfully!" << endl;
}

bool PollutionList::isIdUnique(int id) {
  PollutionNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getId() == id)
      return false;
    temp = temp->next;
  }
  return true;
}

void PollutionList::displayAll() {
  cout << "\n===== ALL POLLUTION RECORDS =====" << endl;
  cout << "DEBUG: Count = " << count
       << ", Head = " << (head == NULL ? "NULL" : "NOT NULL") << endl;

  if (head == NULL) {
    cout << "\nNo pollution records found!" << endl;
    pause();
    return;
  }

  PollutionNode *temp = head;
  int displayed = 0;
  while (temp != NULL) {
    temp->data.display();
    temp = temp->next;
    displayed++;
  }
  cout << "Total Records: " << count << " (Displayed: " << displayed << ")"
       << endl;
  pause();
}

Pollution *PollutionList::searchById(int id) {
  PollutionNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getId() == id) {
      return &(temp->data);
    }
    temp = temp->next;
  }
  return NULL;
}

void PollutionList::sortByValue() {
  if (head == NULL || head->next == NULL)
    return;

  for (int i = 0; i < count - 1; i++) {
    PollutionNode *current = head;
    for (int j = 0; j < count - i - 1; j++) {
      if (current->next != NULL &&
          current->data.getValue() > current->next->data.getValue()) {
        Pollution temp = current->data;
        current->data = current->next->data;
        current->next->data = temp;
      }
      if (current->next != NULL) {
        current = current->next;
      }
    }
  }
  cout << "\nRecords sorted by pollution value!" << endl;
}

void PollutionList::displayByType(string type) {
  bool found = false;
  PollutionNode *temp = head;

  cout << "\n===== " << type << " POLLUTION RECORDS =====" << endl;
  while (temp != NULL) {
    if (temp->data.getType() == type) {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }

  if (!found) {
    cout << "No records found for " << type << " pollution." << endl;
  }
  pause();
}

void PollutionList::displayByLocation(string location) {
  bool found = false;
  PollutionNode *temp = head;

  cout << "\n===== POLLUTION RECORDS FOR " << location << " =====" << endl;
  while (temp != NULL) {
    if (temp->data.getLocation() == location) {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }

  if (!found) {
    cout << "No records found for " << location << "." << endl;
  }
  pause();
}

int PollutionList::getCount() { return count; }

PollutionNode *PollutionList::getHead() { return head; }

void PollutionList::deleteById(int id) {
  if (head == NULL) {
    cout << "\nNo records to delete!" << endl;
    return;
  }

  if (head->data.getId() == id) {
    PollutionNode *temp = head;
    head = head->next;
    delete temp;
    count--;
    cout << "\nRecord deleted successfully!" << endl;
    return;
  }

  PollutionNode *current = head;
  while (current->next != NULL) {
    if (current->next->data.getId() == id) {
      PollutionNode *temp = current->next;
      current->next = current->next->next;
      delete temp;
      count--;
      cout << "\nRecord deleted successfully!" << endl;
      return;
    }
    current = current->next;
  }

  cout << "\nRecord with ID " << id << " not found!" << endl;
}

void PollutionList::generateReport() {
  if (head == NULL) {
    cout << "\nNo data available for report!" << endl;
    return;
  }

  cout << "\n========== POLLUTION REPORT ==========" << endl;

  int safeCount = 0, unsafeCount = 0;
  int airCount = 0, waterCount = 0, soilCount = 0, noiseCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getSafeStatus())
      safeCount++;
    else
      unsafeCount++;

    if (temp->data.getType() == "Air")
      airCount++;
    else if (temp->data.getType() == "Water")
      waterCount++;
    else if (temp->data.getType() == "Soil")
      soilCount++;
    else if (temp->data.getType() == "Noise")
      noiseCount++;

    temp = temp->next;
  }

  cout << "Total Records: " << count << endl;
  cout << "Safe Levels: " << safeCount << endl;
  cout << "Unsafe Levels: " << unsafeCount << endl;
  cout << "\nPollution Type Distribution:" << endl;
  cout << "  Air Pollution: " << airCount << endl;
  cout << "  Water Pollution: " << waterCount << endl;
  cout << "  Soil Pollution: " << soilCount << endl;
  cout << "  Noise Pollution: " << noiseCount << endl;
  cout << "======================================" << endl;
  pause();
}

void PollutionList::trendAnalysis() {
  if (head == NULL) {
    cout << "\nNo data available for trend analysis!" << endl;
    return;
  }

  cout << "\n========== AREA-WISE TREND ANALYSIS ==========" << endl;

  // Collect data per area
  string locations[100];
  float totals[100];
  int counts[100];
  int uniqueCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    string loc = temp->data.getLocation();
    bool found = false;

    for (int i = 0; i < uniqueCount; i++) {
      if (locations[i] == loc) {
        totals[i] += temp->data.getValue();
        counts[i]++;
        found = true;
        break;
      }
    }

    if (!found && uniqueCount < 100) {
      locations[uniqueCount] = loc;
      totals[uniqueCount] = temp->data.getValue();
      counts[uniqueCount] = 1;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Display area-wise trends
  for (int i = 0; i < uniqueCount; i++) {
    float average = totals[i] / counts[i];

    cout << "\n" << locations[i] << ":" << endl;
    cout << "  Average Level: " << average << endl;
    cout << "  Records: " << counts[i] << endl;

    if (average > 75) {
      cout << "  Trend: CRITICAL - Pollution levels are very high!" << endl;
      cout << "  Action: Immediate intervention required!" << endl;
    } else if (average > 50) {
      cout << "  Trend: WARNING - Pollution levels are increasing!" << endl;
      cout << "  Action: Monitor closely and take preventive measures." << endl;
    } else {
      cout << "  Trend: NORMAL - Pollution levels are manageable." << endl;
      cout << "  Action: Continue regular monitoring." << endl;
    }
  }

  cout << "\n==============================================" << endl;
  pause();
}

void PollutionList::predictPollution() {
  if (head == NULL) {
    cout << "\nNo data available for prediction!" << endl;
    return;
  }

  cout << "\n========== AREA-WISE POLLUTION PREDICTION ==========" << endl;

  // Collect data per area
  string locations[100];
  float totals[100];
  int counts[100];
  int uniqueCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    string loc = temp->data.getLocation();
    bool found = false;

    for (int i = 0; i < uniqueCount; i++) {
      if (locations[i] == loc) {
        totals[i] += temp->data.getValue();
        counts[i]++;
        found = true;
        break;
      }
    }

    if (!found && uniqueCount < 100) {
      locations[uniqueCount] = loc;
      totals[uniqueCount] = temp->data.getValue();
      counts[uniqueCount] = 1;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Display area-wise predictions
  for (int i = 0; i < uniqueCount; i++) {
    float average = totals[i] / counts[i];
    float predicted = average * 1.1; // 10% increase prediction

    cout << "\n" << locations[i] << ":" << endl;
    cout << "  Current Average: " << average << endl;
    cout << "  Predicted Level (next period): " << predicted << endl;
    cout << "  Records Analyzed: " << counts[i] << endl;

    if (predicted > 100) {
      cout << "  Prediction: ALERT - May reach dangerous levels!" << endl;
      cout << "  Recommendation: Immediate action required!" << endl;
    } else if (predicted > 75) {
      cout << "  Prediction: WARNING - Levels may increase!" << endl;
      cout << "  Recommendation: Monitor closely and take preventive measures."
           << endl;
    } else {
      cout << "  Prediction: STABLE - Levels expected to remain normal."
           << endl;
      cout << "  Recommendation: Continue regular monitoring." << endl;
    }
  }

  cout << "\n====================================================" << endl;
  pause();
}

// Update pollution value
void PollutionList::updatePollutionValue(int id, float newValue) {
  Pollution *p = searchById(id);
  if (p != NULL) {
    p->setValue(newValue);
    cout << "\nPollution value updated to: " << newValue << endl;
    if (!p->getSafeStatus()) {
      cout << "WARNING: New value is UNSAFE!" << endl;
    }
  } else {
    cout << "\nRecord not found!" << endl;
  }
}

// Calculate average pollution per area
void PollutionList::displayAveragePollutionPerArea() {
  if (head == NULL) {
    cout << "\nNo data available!" << endl;
    return;
  }

  cout << "\n===== AVERAGE POLLUTION PER AREA =====\n";

  // Simple approach: collect unique locations and calculate averages
  string locations[100];
  float totals[100];
  int counts[100];
  int uniqueCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    string loc = temp->data.getLocation();
    bool found = false;

    // Check if location already exists
    for (int i = 0; i < uniqueCount; i++) {
      if (locations[i] == loc) {
        totals[i] += temp->data.getValue();
        counts[i]++;
        found = true;
        break;
      }
    }

    // New location
    if (!found && uniqueCount < 100) {
      locations[uniqueCount] = loc;
      totals[uniqueCount] = temp->data.getValue();
      counts[uniqueCount] = 1;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Display results
  for (int i = 0; i < uniqueCount; i++) {
    float avg = totals[i] / counts[i];
    cout << locations[i] << ": " << avg << " (from " << counts[i]
         << " records)\n";
  }
  cout << "======================================\n";
  pause();
}

// Count unsafe pollution records
int PollutionList::countUnsafeRecords() {
  int unsafeCount = 0;
  PollutionNode *temp = head;

  while (temp != NULL) {
    if (!temp->data.getSafeStatus()) {
      unsafeCount++;
    }
    temp = temp->next;
  }

  cout << "\n===== UNSAFE RECORDS COUNT =====\n";
  cout << "Total Unsafe Records: " << unsafeCount << endl;
  cout << "Total Safe Records: " << (count - unsafeCount) << endl;
  cout << "================================\n";

  return unsafeCount;
}

// Check and display safety alerts for unsafe pollution records
void PollutionList::checkSafetyAlerts() {
  cout << "\n========== SAFETY ALERTS ==========\n";

  int alertCount = 0;
  PollutionNode *temp = head;

  while (temp != NULL) {
    if (!temp->data.getSafeStatus()) {
      cout << "\n[ALERT] ID: " << temp->data.getId() << endl;
      cout << "Type: " << temp->data.getType() << endl;
      cout << "Location: " << temp->data.getLocation() << endl;
      cout << "Value: " << temp->data.getValue() << " " << temp->data.getUnit()
           << endl;
      cout << "Status: UNSAFE" << endl;
      alertCount++;
    }
    temp = temp->next;
  }

  if (alertCount == 0) {
    cout << "No safety alerts! All pollution levels are within safe limits.\n";
  } else {
    cout << "\n" << alertCount << " pollution records exceed safe limits!\n";
  }

  cout << "===================================\n";
  pause();
}

// Area risk scoring system
void PollutionList::displayAreaRiskReport() {
  if (head == NULL) {
    cout << "\nNo data available!" << endl;
    return;
  }

  cout << "\n===== AREA RISK ASSESSMENT =====\n";

  string locations[100];
  int unsafeCounts[100];
  int severityScores[100]; // LOW=1, MED=2, HIGH=3
  int uniqueCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    string loc = temp->data.getLocation();
    bool found = false;

    for (int i = 0; i < uniqueCount; i++) {
      if (locations[i] == loc) {
        if (!temp->data.getSafeStatus()) {
          unsafeCounts[i]++;
        }
        // Add severity weight
        Severity sev = temp->data.getSeverity();
        if (sev == LOW)
          severityScores[i] += 1;
        else if (sev == MEDIUM)
          severityScores[i] += 2;
        else
          severityScores[i] += 3;
        found = true;
        break;
      }
    }

    if (!found && uniqueCount < 100) {
      locations[uniqueCount] = loc;
      unsafeCounts[uniqueCount] = temp->data.getSafeStatus() ? 0 : 1;
      Severity sev = temp->data.getSeverity();
      if (sev == LOW)
        severityScores[uniqueCount] = 1;
      else if (sev == MEDIUM)
        severityScores[uniqueCount] = 2;
      else
        severityScores[uniqueCount] = 3;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Display risk assessment
  for (int i = 0; i < uniqueCount; i++) {
    int riskScore = unsafeCounts[i] * 10 + severityScores[i];
    string riskLevel;

    if (riskScore < 15)
      riskLevel = "LOW";
    else if (riskScore < 30)
      riskLevel = "MODERATE";
    else
      riskLevel = "HIGH";

    cout << locations[i] << ":\n";
    cout << "  Unsafe Records: " << unsafeCounts[i] << "\n";
    cout << "  Risk Score: " << riskScore << "\n";
    cout << "  Risk Level: " << riskLevel << "\n\n";
  }
  cout << "================================\n";
  pause();
}

// Trend analysis
void PollutionList::displayTrendReport() {
  if (head == NULL) {
    cout << "\nNo data available!" << endl;
    return;
  }

  cout << "\n===== POLLUTION TREND ANALYSIS =====\n";

  string locations[100];
  float firstValues[100];
  float lastValues[100];
  int counts[100];
  int uniqueCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    string loc = temp->data.getLocation();
    bool found = false;

    for (int i = 0; i < uniqueCount; i++) {
      if (locations[i] == loc) {
        lastValues[i] = temp->data.getValue();
        counts[i]++;
        found = true;
        break;
      }
    }

    if (!found && uniqueCount < 100) {
      locations[uniqueCount] = loc;
      firstValues[uniqueCount] = temp->data.getValue();
      lastValues[uniqueCount] = temp->data.getValue();
      counts[uniqueCount] = 1;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Display trends
  for (int i = 0; i < uniqueCount; i++) {
    if (counts[i] < 2) {
      cout << locations[i] << ": INSUFFICIENT DATA\n";
      continue;
    }

    float change = lastValues[i] - firstValues[i];
    string trend;

    if (change > 5)
      trend = "INCREASING";
    else if (change < -5)
      trend = "DECREASING";
    else
      trend = "STABLE";

    cout << locations[i] << ": " << trend;
    cout << " (Change: " << change << ")\n";
  }
  cout << "====================================\n";
  pause();
}

// Severity distribution report
void PollutionList::displaySeverityDistribution() {
  if (head == NULL) {
    cout << "\nNo data available!" << endl;
    return;
  }

  cout << "\n===== SEVERITY DISTRIBUTION =====\n";

  int lowCount = 0, medCount = 0, highCount = 0;

  PollutionNode *temp = head;
  while (temp != NULL) {
    Severity sev = temp->data.getSeverity();
    if (sev == LOW)
      lowCount++;
    else if (sev == MEDIUM)
      medCount++;
    else
      highCount++;
    temp = temp->next;
  }

  cout << "LOW Severity: " << lowCount << " records\n";
  cout << "MEDIUM Severity: " << medCount << " records\n";
  cout << "HIGH Severity: " << highCount << " records\n";
  cout << "Total: " << count << " records\n";
  cout << "=================================\n";
  pause();
}

string Pollution::classifyRisk() {
  if (isSafe) {
    return "Safe";
  }
  if (severity == HIGH) {
    return "Dangerous";
  }
  if (severity == MEDIUM) {
    return "Moderate";
  }
  return "Safe";
}

bool Pollution::shouldGenerateAlert() { return !isSafe && severity >= MEDIUM; }

void Pollution::updateTrend() {
  if (previousValue == 0.0) {
    trend = "New";
    return;
  }
  float change = value - previousValue;
  if (change > 5.0) {
    trend = "Increasing";
  } else if (change < -5.0) {
    trend = "Decreasing";
  } else {
    trend = "Stable";
  }
}

void Pollution::setPreviousValue(float val) {
  previousValue = val;
  updateTrend();
}

float Pollution::getPreviousValue() { return previousValue; }

string Pollution::getTrend() { return trend; }

string Pollution::getLastUpdated() { return lastUpdated; }

void Pollution::setLastUpdated(string time) { lastUpdated = time; }

// ===== COMPLAINT CLASS IMPLEMENTATIONS =====

Complaint::Complaint() {
  complaintId = 0;
  citizenName = "";
  location = "";
  pollutionType = "";
  description = "";
  date = "";
  status = "Pending";
  linkedPollutionId = -1;
  priority = "Normal";
}

Complaint::Complaint(int id, string name, string loc, string type, string desc,
                     string d) {
  complaintId = id;
  citizenName = name;
  location = loc;
  pollutionType = type;
  description = desc;
  date = d;
  status = "Pending";
  linkedPollutionId = -1;
  priority = "Normal";
}

int Complaint::getId() { return complaintId; }
string Complaint::getCitizenName() { return citizenName; }
string Complaint::getLocation() { return location; }
string Complaint::getPollutionType() { return pollutionType; }
string Complaint::getDescription() { return description; }
string Complaint::getDate() { return date; }
string Complaint::getStatus() { return status; }

void Complaint::setId(int id) { complaintId = id; }
void Complaint::setCitizenName(string name) { citizenName = name; }
void Complaint::setLocation(string loc) { location = loc; }
void Complaint::setPollutionType(string type) { pollutionType = type; }
void Complaint::setDescription(string desc) { description = desc; }
void Complaint::setDate(string d) { date = d; }
void Complaint::setStatus(string s) { status = s; }

void Complaint::display() {
  cout << "\n--- Complaint Details ---" << endl;
  cout << "ID: " << complaintId << endl;
  cout << "Citizen: " << citizenName << endl;
  cout << "Location: " << location << endl;
  cout << "Type: " << pollutionType << endl;
  cout << "Description: " << description << endl;
  cout << "Date: " << date << endl;
  cout << "Status: " << status << endl;
  cout << "Priority: " << priority << endl;
  if (linkedPollutionId != -1) {
    cout << "Linked to Pollution ID: " << linkedPollutionId << endl;
  }
  cout << "------------------------" << endl;
}

string Complaint::toString() {
  return to_string(complaintId) + "," + citizenName + "," + location + "," +
         pollutionType + "," + description + "," + date + "," + status;
}

void Complaint::linkToPollution(int pollutionId) {
  linkedPollutionId = pollutionId;
  cout << "\nComplaint linked to Pollution ID: " << pollutionId << endl;
}

void Complaint::escalate() {
  if (priority == "Normal") {
    priority = "High";
  } else if (priority == "High") {
    priority = "Critical";
  }
  cout << "\nComplaint escalated to: " << priority << endl;
}

bool Complaint::isLinked() { return linkedPollutionId != -1; }

int Complaint::getLinkedPollutionId() { return linkedPollutionId; }

string Complaint::getPriority() { return priority; }

void Complaint::setPriority(string p) { priority = p; }

bool Complaint::isValidPollutionType(string type) {
  return (type == "Air" || type == "Water" || type == "Soil" ||
          type == "Noise");
}

bool Complaint::isValidDate(string date) {
  return date.length() >= 8 && date.length() <= 12;
}

bool Complaint::isValidStatus(string status) {
  return (status == "Pending" || status == "In Progress" ||
          status == "Resolved");
}

bool Complaint::isValidName(string name) {
  return name.length() > 0 && name.length() <= 50;
}

bool Complaint::isValidLocation(string location) {
  return location.length() > 0 && location.length() <= 50;
}

// ===== COMPLAINT LIST IMPLEMENTATIONS =====

ComplaintList::ComplaintList() {
  head = NULL;
  count = 0;
}

ComplaintList::~ComplaintList() {
  ComplaintNode *current = head;
  while (current != NULL) {
    ComplaintNode *temp = current;
    current = current->next;
    delete temp;
  }
}

void ComplaintList::addComplaint(Complaint c) {
  if (!isIdUnique(c.getId())) {
    cout << "\nError: Complaint ID already exists!" << endl;
    return;
  }

  if (!Complaint::isValidName(c.getCitizenName())) {
    cout << "\nError: Invalid citizen name!" << endl;
    return;
  }

  if (!Complaint::isValidLocation(c.getLocation())) {
    cout << "\nError: Invalid location!" << endl;
    return;
  }

  ComplaintNode *newNode = new ComplaintNode(c);

  if (head == NULL) {
    head = newNode;
  } else {
    ComplaintNode *temp = head;
    while (temp->next != NULL) {
      temp = temp->next;
    }
    temp->next = newNode;
  }
  count++;
  cout << "\nComplaint added successfully!" << endl;

  // Automatically recalculate priorities based on complaint density
  calculateAutoPriority();
  cout << "Priorities updated based on complaint density." << endl;
}

bool ComplaintList::isIdUnique(int id) {
  ComplaintNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getId() == id)
      return false;
    temp = temp->next;
  }
  return true;
}

void ComplaintList::displayAll() {
  if (head == NULL) {
    cout << "\nNo complaints found!" << endl;
    pause();
    return;
  }

  cout << "\n===== ALL COMPLAINTS =====" << endl;
  ComplaintNode *temp = head;
  while (temp != NULL) {
    temp->data.display();
    temp = temp->next;
  }
  cout << "Total Complaints: " << count << endl;
  pause();
}

void ComplaintList::displayPending() {
  bool found = false;
  cout << "\n===== PENDING COMPLAINTS =====" << endl;
  ComplaintNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getStatus() == "Pending") {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }
  if (!found) {
    cout << "No pending complaints!" << endl;
  }
  pause();
}

void ComplaintList::displayResolved() {
  bool found = false;
  cout << "\n===== RESOLVED COMPLAINTS =====" << endl;
  ComplaintNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getStatus() == "Resolved") {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }
  if (!found) {
    cout << "No resolved complaints!" << endl;
  }
  pause();
}

Complaint *ComplaintList::searchById(int id) {
  ComplaintNode *temp = head;
  while (temp != NULL) {
    if (temp->data.getId() == id) {
      return &(temp->data);
    }
    temp = temp->next;
  }
  return NULL;
}

void ComplaintList::updateStatus(int id, string newStatus) {
  Complaint *c = searchById(id);
  if (c != NULL) {
    c->setStatus(newStatus);
    cout << "\nComplaint status updated to: " << newStatus << endl;
  } else {
    cout << "\nComplaint not found!" << endl;
  }
}

void ComplaintList::deleteComplaint(int id) {
  if (head == NULL) {
    cout << "\nNo complaints to delete!" << endl;
    return;
  }

  if (head->data.getId() == id) {
    ComplaintNode *temp = head;
    head = head->next;
    delete temp;
    count--;
    cout << "\nComplaint deleted successfully!" << endl;
    return;
  }

  ComplaintNode *current = head;
  while (current->next != NULL) {
    if (current->next->data.getId() == id) {
      ComplaintNode *temp = current->next;
      current->next = current->next->next;
      delete temp;
      count--;
      cout << "\nComplaint deleted successfully!" << endl;
      return;
    }
    current = current->next;
  }

  cout << "\nComplaint with ID " << id << " not found!" << endl;
}

int ComplaintList::getCount() { return count; }

ComplaintNode *ComplaintList::getHead() { return head; }

void ComplaintList::sortByDate() {
  if (head == NULL || head->next == NULL)
    return;

  for (int i = 0; i < count - 1; i++) {
    ComplaintNode *current = head;
    for (int j = 0; j < count - i - 1; j++) {
      if (current->next != NULL &&
          current->data.getDate() > current->next->data.getDate()) {
        Complaint temp = current->data;
        current->data = current->next->data;
        current->next->data = temp;
      }
      if (current->next != NULL) {
        current = current->next;
      }
    }
  }
  cout << "\nComplaints sorted by date!" << endl;
}

void ComplaintList::displayByType(string type) {
  bool found = false;
  ComplaintNode *temp = head;

  cout << "\n===== " << type << " COMPLAINTS =====" << endl;
  while (temp != NULL) {
    if (temp->data.getPollutionType() == type) {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }

  if (!found) {
    cout << "No complaints found for " << type << " pollution." << endl;
  }
  pause();
}

void ComplaintList::displayByLocation(string location) {
  bool found = false;
  ComplaintNode *temp = head;

  cout << "\n===== COMPLAINTS FOR " << location << " =====" << endl;
  while (temp != NULL) {
    if (temp->data.getLocation() == location) {
      temp->data.display();
      found = true;
    }
    temp = temp->next;
  }

  if (!found) {
    cout << "No complaints found for " << location << "." << endl;
  }
  pause();
}

void ComplaintList::resolveComplaint(int id) {
  Complaint *c = searchById(id);
  if (c != NULL) {
    c->setStatus("Resolved");
    cout << "\nComplaint marked as resolved!" << endl;
  } else {
    cout << "\nComplaint not found!" << endl;
  }
}

void ComplaintList::displayResolutionStats() {
  int pending = 0, inProgress = 0, resolved = 0;
  ComplaintNode *temp = head;

  while (temp != NULL) {
    string status = temp->data.getStatus();

    // Case-insensitive comparison for better matching
    if (status == "Pending" || status == "pending")
      pending++;
    else if (status == "In Progress" || status == "in progress" ||
             status == "In progress")
      inProgress++;
    else if (status == "Resolved" || status == "resolved")
      resolved++;
    temp = temp->next;
  }

  cout << "\n===== RESOLUTION STATISTICS =====" << endl;
  cout << "Total Complaints: " << count << endl;
  cout << "Pending: " << pending << endl;
  cout << "In Progress: " << inProgress << endl;
  cout << "Resolved: " << resolved << endl;
  cout << "=================================" << endl;
  pause();
}

void ComplaintList::displayTypeDistribution() {
  int air = 0, water = 0, soil = 0, noise = 0;
  ComplaintNode *temp = head;

  while (temp != NULL) {
    if (temp->data.getPollutionType() == "Air")
      air++;
    else if (temp->data.getPollutionType() == "Water")
      water++;
    else if (temp->data.getPollutionType() == "Soil")
      soil++;
    else if (temp->data.getPollutionType() == "Noise")
      noise++;
    temp = temp->next;
  }

  cout << "\n===== COMPLAINT TYPE DISTRIBUTION =====" << endl;
  cout << "Air Pollution: " << air << endl;
  cout << "Water Pollution: " << water << endl;
  cout << "Soil Pollution: " << soil << endl;
  cout << "Noise Pollution: " << noise << endl;
  cout << "=======================================" << endl;
  pause();
}

// Calculate and assign automatic priorities based on complaint density
void ComplaintList::calculateAutoPriority() {
  if (head == NULL) {
    return;
  }

  // Arrays to store unique location+type combinations and their counts
  string locationTypes[100]; // Combined "location|type" strings
  int counts[100];
  int uniqueCount = 0;

  // First pass: Count complaints per location+type combination
  ComplaintNode *temp = head;
  while (temp != NULL) {
    string locType =
        temp->data.getLocation() + "|" + temp->data.getPollutionType();
    bool found = false;

    // Check if this location+type combo already exists
    for (int i = 0; i < uniqueCount; i++) {
      if (locationTypes[i] == locType) {
        counts[i]++;
        found = true;
        break;
      }
    }

    // New location+type combination
    if (!found && uniqueCount < 100) {
      locationTypes[uniqueCount] = locType;
      counts[uniqueCount] = 1;
      uniqueCount++;
    }

    temp = temp->next;
  }

  // Second pass: Assign priorities based on counts
  temp = head;
  while (temp != NULL) {
    string locType =
        temp->data.getLocation() + "|" + temp->data.getPollutionType();

    // Find the count for this location+type
    for (int i = 0; i < uniqueCount; i++) {
      if (locationTypes[i] == locType) {
        // Assign priority based on count
        if (counts[i] == 1) {
          temp->data.setPriority("Normal");
        } else if (counts[i] >= 2 && counts[i] <= 3) {
          temp->data.setPriority("High");
        } else {
          temp->data.setPriority("Critical");
        }
        break;
      }
    }

    temp = temp->next;
  }
}

// ===== SENSOR CLASS IMPLEMENTATIONS =====

Sensor::Sensor() {
  sensorId = 0;
  sensorType = "";
  location = "";
  isActive = true;
  lastReading = 0.0;
  faultCount = 0;
}

Sensor::Sensor(int id, string type, string loc) {
  sensorId = id;
  sensorType = type;
  location = loc;
  isActive = true;
  lastReading = 0.0;
  faultCount = 0;
}

int Sensor::getId() { return sensorId; }
string Sensor::getType() { return sensorType; }
string Sensor::getLocation() { return location; }
bool Sensor::getStatus() { return isActive; }
float Sensor::getLastReading() { return lastReading; }

void Sensor::setId(int id) { sensorId = id; }
void Sensor::setType(string type) { sensorType = type; }
void Sensor::setLocation(string loc) { location = loc; }
void Sensor::setStatus(bool status) { isActive = status; }
void Sensor::setLastReading(float reading) { lastReading = reading; }

float Sensor::generateReading() {
  srand(time(0) + sensorId);

  float reading = 0.0;
  bool isFaulty = false;

  // Define safe ranges for each pollution type
  const float AIR_MAX = 100.0;
  const float WATER_MIN = 6.5;
  const float WATER_MAX = 8.5;
  const float SOIL_MAX = 70.0;
  const float NOISE_MAX = 85.0;

  if (sensorType == "Air") {
    reading = 20.0 + (rand() % 100); // Range: 20-120
    if (reading > AIR_MAX) {
      isFaulty = true;
    }
  } else if (sensorType == "Water") {
    reading = 6.0 + (rand() % 4); // Range: 6-10 pH
    if (reading < WATER_MIN || reading > WATER_MAX) {
      isFaulty = true;
    }
  } else if (sensorType == "Soil") {
    reading = 10.0 + (rand() % 80); // Range: 10-90
    if (reading > SOIL_MAX) {
      isFaulty = true;
    }
  } else if (sensorType == "Noise") {
    reading = 50.0 + (rand() % 50); // Range: 50-100 dB
    if (reading > NOISE_MAX) {
      isFaulty = true;
    }
  }

  lastReading = reading;

  // Increment fault count if reading is out of safe range
  if (isFaulty) {
    incrementFaultCount();
    cout << "\n[WARNING] Sensor " << sensorId << " (" << sensorType
         << ") detected unsafe reading: " << reading
         << " - Fault count incremented!" << endl;
  }

  return reading;
}

void Sensor::display() {
  cout << "\n--- Sensor Details ---" << endl;
  cout << "Sensor ID: " << sensorId << endl;
  cout << "Type: " << sensorType << endl;
  cout << "Location: " << location << endl;
  cout << "Status: " << (isActive ? "Active" : "Inactive") << endl;
  cout << "Last Reading: " << lastReading << endl;
  cout << "Fault Count: " << faultCount << endl;
  cout << "----------------------" << endl;
}

bool Sensor::isFaulty() {
  if (sensorType == "Air" && (lastReading < 0 || lastReading > 500))
    return true;
  if (sensorType == "Water" && (lastReading < 0 || lastReading > 14))
    return true;
  if (sensorType == "Soil" && (lastReading < 0 || lastReading > 200))
    return true;
  if (sensorType == "Noise" && (lastReading < 0 || lastReading > 150))
    return true;
  return false;
}

bool Sensor::isValidType(string type) {
  return (type == "Air" || type == "Water" || type == "Soil" ||
          type == "Noise");
}

bool Sensor::isValidString(string str, int maxLen) {
  if (str.length() == 0 || str.length() > maxLen)
    return false;
  return true;
}

// ===== SENSOR QUEUE IMPLEMENTATIONS =====

SensorQueue::SensorQueue() {
  front = NULL;
  rear = NULL;
  size = 0;
}

SensorQueue::~SensorQueue() {
  while (!isEmpty()) {
    dequeue();
  }
}

void SensorQueue::enqueue(Sensor s) {
  QueueNode *newNode = new QueueNode(s);

  if (rear == NULL) {
    front = rear = newNode;
  } else {
    rear->next = newNode;
    rear = newNode;
  }
  size++;
}

Sensor SensorQueue::dequeue() {
  if (isEmpty()) {
    cout << "Queue is empty!" << endl;
    return Sensor();
  }

  QueueNode *temp = front;
  Sensor s = front->data;
  front = front->next;

  if (front == NULL) {
    rear = NULL;
  }

  delete temp;
  size--;
  return s;
}

bool SensorQueue::isEmpty() { return front == NULL; }

int SensorQueue::getSize() { return size; }

void SensorQueue::displayQueue() {
  if (isEmpty()) {
    cout << "\nQueue is empty!" << endl;
    return;
  }

  cout << "\n===== SENSOR QUEUE =====" << endl;
  QueueNode *temp = front;
  int position = 1;
  while (temp != NULL) {
    cout << "\nPosition " << position << ":" << endl;
    temp->data.display();
    temp = temp->next;
    position++;
  }
  cout << "Total sensors in queue: " << size << endl;
}

void SensorQueue::processAllSensors() {
  if (isEmpty()) {
    cout << "\nNo sensors to process!" << endl;
    return;
  }

  cout << "\n===== PROCESSING SENSORS =====" << endl;
  int processed = 0;

  while (!isEmpty()) {
    Sensor s = dequeue();
    cout << "\nProcessing Sensor ID: " << s.getId() << endl;
    float reading = s.generateReading();
    cout << "Reading: " << reading << endl;

    if (s.isFaulty()) {
      cout << "WARNING: Faulty reading detected!" << endl;
    } else {
      cout << "Reading processed successfully." << endl;
    }
    processed++;
  }

  cout << "\nTotal sensors processed: " << processed << endl;
}

// ===== SENSOR CLASS IMPLEMENTATIONS =====

SensorManager::SensorManager() { sensorCount = 0; }

void SensorManager::addSensor(Sensor s) {
  if (sensorCount >= 50) {
    cout << "\nSensor array is full!" << endl;
    return;
  }

  if (!Sensor::isValidString(s.getLocation(), 50)) {
    cout << "\nError: Location invalid (max 50 chars)!" << endl;
    return;
  }

  if (!Sensor::isValidType(s.getType())) {
    cout << "\nError: Invalid type! Use Air/Water/Soil/Noise" << endl;
    return;
  }

  if (!isNameUnique(to_string(s.getId()), s.getLocation())) {
    cout << "\nError: Sensor already exists in this location!" << endl;
    return;
  }

  sensors[sensorCount] = s;
  sensorCount++;
  cout << "\nSensor added successfully!" << endl;
}

bool SensorManager::isNameUnique(string name, string location) {
  for (int i = 0; i < sensorCount; i++) {
    if (to_string(sensors[i].getId()) == name &&
        sensors[i].getLocation() == location) {
      return false;
    }
  }
  return true;
}

void SensorManager::displayAllSensors() {
  if (sensorCount == 0) {
    cout << "\nNo sensors registered!" << endl;
    return;
  }

  cout << "\n===== ALL SENSORS =====" << endl;
  for (int i = 0; i < sensorCount; i++) {
    sensors[i].display();
  }
  cout << "Total sensors: " << sensorCount << endl;
  pause();
}

void SensorManager::displayActiveSensors() {
  bool found = false;
  cout << "\n===== ACTIVE SENSORS =====" << endl;
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getStatus()) {
      sensors[i].display();
      found = true;
    }
  }
  if (!found) {
    cout << "No active sensors found!" << endl;
  }
  pause();
}

void SensorManager::displayInactiveSensors() {
  bool found = false;
  cout << "\n===== INACTIVE SENSORS =====" << endl;
  for (int i = 0; i < sensorCount; i++) {
    if (!sensors[i].getStatus()) {
      sensors[i].display();
      found = true;
    }
  }
  if (!found) {
    cout << "No inactive sensors found!" << endl;
  }
  pause();
}

Sensor *SensorManager::findSensorById(int id) {
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getId() == id) {
      return &sensors[i];
    }
  }
  return NULL;
}

void SensorManager::toggleSensorStatus(int id) {
  Sensor *s = findSensorById(id);
  if (s != NULL) {
    s->setStatus(!s->getStatus());
    cout << "\nSensor status toggled!" << endl;
  } else {
    cout << "\nSensor not found!" << endl;
  }
}

void SensorManager::manualDataEntry() {
  int id;
  float reading;

  cout << "\nEnter Sensor ID: ";
  cin >> id;

  Sensor *s = findSensorById(id);
  if (s != NULL) {
    cout << "Enter reading value: ";
    cin >> reading;
    s->setLastReading(reading);

    if (s->isFaulty()) {
      cout << "WARNING: Abnormal reading detected!" << endl;
    } else {
      cout << "Reading recorded successfully!" << endl;
    }
  } else {
    cout << "Sensor not found!" << endl;
  }
}

void SensorManager::simulateAllReadings() {
  cout << "\n===== SIMULATING SENSOR READINGS =====" << endl;
  int simulated = 0;

  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getStatus()) {
      float reading = sensors[i].generateReading();
      cout << "Sensor " << sensors[i].getId() << ": " << reading << endl;
      simulated++;
    }
  }

  cout << "\nTotal readings simulated: " << simulated << endl;
}

int SensorManager::getSensorCount() { return sensorCount; }

// Auto-deactivate faulty sensors
void SensorManager::deactivateFaultySensors() {
  cout << "\n===== CHECKING FOR FAULTY SENSORS =====\n";
  int deactivated = 0;

  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getStatus() && sensors[i].isFaulty()) {
      sensors[i].setStatus(false);
      cout << "Sensor " << sensors[i].getId()
           << " deactivated (faulty reading: " << sensors[i].getLastReading()
           << ")\n";
      deactivated++;
    }
  }

  if (deactivated == 0) {
    cout << "No faulty sensors found.\n";
  } else {
    cout << "\nTotal sensors deactivated: " << deactivated << endl;
  }
  cout << "=======================================\n";
}

// Sensor health management
void Sensor::incrementFaultCount() {
  faultCount++;
  if (shouldDeactivate()) {
    isActive = false;
    cout << "Sensor " << sensorId << " auto-deactivated after " << faultCount
         << " faults!\n";
  }
}

void Sensor::resetFaultCount() {
  faultCount = 0;
  isActive = true;
}

bool Sensor::shouldDeactivate() { return faultCount >= 3; }

int Sensor::getFaultCount() { return faultCount; }

// Reset sensor health
void SensorManager::resetSensorHealth(int id) {
  Sensor *s = findSensorById(id);
  if (s != NULL) {
    s->resetFaultCount();
    cout << "\nSensor " << id
         << " health reset! Fault count cleared and sensor reactivated.\n";
  } else {
    cout << "\nSensor not found!\n";
  }
}

// Emergency shutdown all sensors in an area
void SensorManager::emergencyShutdownByArea(string area) {
  cout << "\n!!! EMERGENCY SHUTDOWN INITIATED !!!\n";
  cout << "Deactivating all sensors in: " << area << endl;

  int deactivated = 0;
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getLocation() == area && sensors[i].getStatus()) {
      sensors[i].setStatus(false);
      deactivated++;
    }
  }

  cout << "Total sensors deactivated: " << deactivated << endl;
  cout << "!!! EMERGENCY SHUTDOWN COMPLETE !!!\n";
}

// Count active sensors in area
int SensorManager::countActiveInArea(string area) {
  int activeCount = 0;
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getLocation() == area && sensors[i].getStatus()) {
      activeCount++;
    }
  }
  return activeCount;
}

// Count faulty sensors
int SensorManager::countFaultySensors() {
  int faultyCount = 0;
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getFaultCount() >= 3) {
      faultyCount++;
    }
  }
  return faultyCount;
}

// Delete sensor by ID
void SensorManager::deleteSensor(int id) {
  int index = -1;

  // Find sensor index
  for (int i = 0; i < sensorCount; i++) {
    if (sensors[i].getId() == id) {
      index = i;
      break;
    }
  }

  if (index == -1) {
    cout << "\nSensor not found!" << endl;
    return;
  }

  // Shift all sensors after the deleted one
  for (int i = index; i < sensorCount - 1; i++) {
    sensors[i] = sensors[i + 1];
  }

  sensorCount--;
  cout << "\nSensor " << id << " deleted successfully!" << endl;
}

// ===== UNDO STACK IMPLEMENTATIONS =====

UndoStack::UndoStack() {
  top = NULL;
  size = 0;
  maxSize = 50;
}

UndoStack::UndoStack(int max) {
  top = NULL;
  size = 0;
  maxSize = max;
}

UndoStack::~UndoStack() {
  while (!isEmpty()) {
    pop();
  }
}

void UndoStack::push(Operation op) {
  if (isFull()) {
    cout << "\nUndo history is full! Oldest operation will be removed." << endl;
  }

  StackNode *newNode = new StackNode(op);
  newNode->next = top;
  top = newNode;
  size++;

  cout << "\nOperation recorded for undo." << endl;
}

Operation UndoStack::pop() {
  if (isEmpty()) {
    cout << "\nNo operations to undo!" << endl;
    return Operation();
  }

  StackNode *temp = top;
  Operation op = top->data;
  top = top->next;
  delete temp;
  size--;

  return op;
}

Operation UndoStack::peek() {
  if (isEmpty()) {
    cout << "\nNo operations in stack!" << endl;
    return Operation();
  }

  return top->data;
}

bool UndoStack::isEmpty() { return top == NULL; }

bool UndoStack::isFull() { return size >= maxSize; }

int UndoStack::getSize() { return size; }

void UndoStack::displayStack() {
  if (isEmpty()) {
    cout << "\nNo undo history!" << endl;
    return;
  }

  cout << "\n===== UNDO HISTORY =====" << endl;
  StackNode *temp = top;
  int position = 1;

  while (temp != NULL) {
    cout << "\n--- Operation " << position << " ---" << endl;
    temp->data.display();
    temp = temp->next;
    position++;
  }

  cout << "\nTotal operations in history: " << size << endl;
}

void UndoStack::clear() {
  while (!isEmpty()) {
    pop();
  }
  cout << "\nUndo history cleared!" << endl;
}

// ===== AREA TREE IMPLEMENTATIONS =====

// External declarations for sensor integration
extern SensorManager sensorManager;
extern int sensorIdCounter;

AreaTree::AreaTree() { root = NULL; }

AreaTree::~AreaTree() {}

void AreaTree::createRoot(string countryName) {
  if (!isValidString(countryName, 50)) {
    cout << "\nError: Country name invalid (max 50 chars)!" << endl;
    return;
  }

  if (root == NULL) {
    root = new TreeNode(countryName, "Country", 0);
    cout << "\nCountry '" << countryName << "' created as root!" << endl;
  } else {
    cout << "\nRoot already exists!" << endl;
  }
}

void AreaTree::addCity(string cityName) {
  if (root == NULL) {
    cout << "\nError: Please create country first!" << endl;
    return;
  }

  if (!isValidString(cityName, 50)) {
    cout << "\nError: City name invalid (max 50 chars)!" << endl;
    return;
  }

  // Check for duplicate city name
  if (findCity(cityName) != NULL) {
    cout << "\nError: City '" << cityName << "' already exists!" << endl;
    return;
  }

  if (root->childCount >= 10) {
    cout << "\nError: Maximum cities reached (max 10)!" << endl;
    return;
  }

  TreeNode *newCity = new TreeNode(cityName, "City", 1);
  newCity->parent = root;
  root->children[root->childCount] = newCity;
  root->childCount++;
  cout << "\nCity '" << cityName << "' added successfully!" << endl;
}

void AreaTree::addArea(string cityName, string areaName) {
  TreeNode *city = findCity(cityName);

  if (city == NULL) {
    cout << "\nError: City '" << cityName << "' not found!" << endl;
    return;
  }

  if (!isValidString(areaName, 50)) {
    cout << "\nError: Area name invalid (max 50 chars)!" << endl;
    return;
  }

  // Check for duplicate area name in this city
  if (findArea(cityName, areaName) != NULL) {
    cout << "\nError: Area '" << areaName << "' already exists in city '"
         << cityName << "'!" << endl;
    return;
  }

  if (city->childCount >= 10) {
    cout << "\nError: Maximum areas reached for this city (max 10)!" << endl;
    return;
  }

  TreeNode *newArea = new TreeNode(areaName, "Area", 2);
  newArea->parent = city;
  city->children[city->childCount] = newArea;
  city->childCount++;
  cout << "\nArea '" << areaName << "' added to city '" << cityName << "'!"
       << endl;
}

void AreaTree::addSensor(string cityName, string areaName, string sensorName,
                         string sensorType) {
  TreeNode *area = findArea(cityName, areaName);

  if (area == NULL) {
    cout << "\nError: Area '" << areaName << "' not found!" << endl;
    return;
  }

  if (!isValidString(sensorName, 50)) {
    cout << "\nError: Sensor name invalid (max 50 chars)!" << endl;
    return;
  }

  if (!Sensor::isValidType(sensorType)) {
    cout << "\nError: Invalid sensor type! Use Air/Water/Soil/Noise" << endl;
    return;
  }

  // Check for duplicate sensor name in this area
  if (findSensor(cityName, areaName, sensorName) != NULL) {
    cout << "\nError: Sensor '" << sensorName << "' already exists in area '"
         << areaName << "'!" << endl;
    return;
  }

  if (area->childCount >= 10) {
    cout << "\nError: Maximum sensors reached for this area (max 10)!" << endl;
    return;
  }

  TreeNode *newSensor = new TreeNode(sensorName, "Sensor:" + sensorType, 3);
  newSensor->parent = area;
  area->children[area->childCount] = newSensor;
  area->childCount++;

  // Also add to Sensor Management system
  string fullLocation = cityName + "/" + areaName;
  Sensor s(sensorIdCounter++, sensorType, fullLocation);
  sensorManager.addSensor(s);

  cout << "\nSensor '" << sensorName << "' added to area '" << areaName << "'!"
       << endl;
  cout << "Sensor also registered in Sensor Management (ID: "
       << (sensorIdCounter - 1) << ")" << endl;
}

void AreaTree::displayTree() {
  if (root == NULL) {
    cout << "\nTree is empty!" << endl;
    pause();
    return;
  }

  cout << "\n===== AREA TREE STRUCTURE =====" << endl;
  cout << "Root: " << root->name << " (Children: " << root->childCount << ")"
       << endl;
  displayTreeHelper(root, 0);
  cout << "================================" << endl;
  pause();
}

void AreaTree::displayTreeHelper(TreeNode *node, int indent) {
  if (node == NULL)
    return;

  for (int i = 0; i < indent; i++) {
    cout << "  ";
  }

  cout << "|- " << node->name << " (" << node->type << ")" << endl;

  for (int i = 0; i < node->childCount; i++) {
    displayTreeHelper(node->children[i], indent + 1);
  }
}

void AreaTree::displayCities() {
  if (root == NULL) {
    cout << "\nTree is empty!" << endl;
    return;
  }

  cout << "\n===== CITIES =====" << endl;
  for (int i = 0; i < root->childCount; i++) {
    cout << (i + 1) << ". " << root->children[i]->name << endl;
  }
  cout << "Total cities: " << root->childCount << endl;
}

void AreaTree::displayAreas(string cityName) {
  TreeNode *city = findCity(cityName);

  if (city == NULL) {
    cout << "\nCity '" << cityName << "' not found!" << endl;
    return;
  }

  cout << "\n===== AREAS IN " << cityName << " =====" << endl;
  for (int i = 0; i < city->childCount; i++) {
    cout << (i + 1) << ". " << city->children[i]->name << endl;
  }
  cout << "Total areas: " << city->childCount << endl;
  pause();
}

void AreaTree::displaySensors(string cityName, string areaName) {
  TreeNode *area = findArea(cityName, areaName);

  if (area == NULL) {
    cout << "\nArea '" << areaName << "' not found!" << endl;
    return;
  }

  cout << "\n===== SENSORS IN " << areaName << " =====" << endl;
  for (int i = 0; i < area->childCount; i++) {
    cout << (i + 1) << ". " << area->children[i]->name << endl;
  }
  cout << "Total sensors: " << area->childCount << endl;
}

TreeNode *AreaTree::findCity(string cityName) {
  if (root == NULL)
    return NULL;

  for (int i = 0; i < root->childCount; i++) {
    if (root->children[i]->name == cityName) {
      return root->children[i];
    }
  }
  return NULL;
}

TreeNode *AreaTree::findArea(string cityName, string areaName) {
  TreeNode *city = findCity(cityName);
  if (city == NULL)
    return NULL;

  for (int i = 0; i < city->childCount; i++) {
    if (city->children[i]->name == areaName) {
      return city->children[i];
    }
  }
  return NULL;
}

TreeNode *AreaTree::findSensor(string cityName, string areaName,
                               string sensorName) {
  TreeNode *area = findArea(cityName, areaName);
  if (area == NULL)
    return NULL;

  for (int i = 0; i < area->childCount; i++) {
    if (area->children[i]->name == sensorName) {
      return area->children[i];
    }
  }
  return NULL;
}

int AreaTree::getTotalNodes() { return countNodesHelper(root); }

int AreaTree::countNodesHelper(TreeNode *node) {
  if (node == NULL)
    return 0;

  int count = 1;

  for (int i = 0; i < node->childCount; i++) {
    count += countNodesHelper(node->children[i]);
  }

  return count;
}

void AreaTree::displayPath(string cityName, string areaName) {
  TreeNode *area = findArea(cityName, areaName);

  if (area == NULL) {
    cout << "\nArea not found!" << endl;
    return;
  }

  cout << "\n===== PATH =====" << endl;
  cout << root->name << " -> " << cityName << " -> " << areaName << endl;
}

TreeNode *AreaTree::getRoot() { return root; }

bool AreaTree::isValidString(string str, int maxLen) {
  if (str.length() == 0 || str.length() > maxLen)
    return false;
  return true;
}

void AreaTree::saveTreeToFile(string filename) {
  ofstream outFile(filename.c_str());

  if (!outFile) {
    cout << "\nError: Cannot create file for saving tree!" << endl;
    return;
  }

  if (root == NULL) {
    cout << "\nTree is empty. Nothing to save." << endl;
    outFile.close();
    return;
  }

  saveTreeHelper(root, outFile, 0);

  outFile.close();
  cout << "\nTree saved successfully to " << filename << endl;
}

void AreaTree::saveTreeHelper(TreeNode *node, ofstream &file, int indent) {
  if (node == NULL)
    return;

  // Write indentation (2 spaces per level)
  for (int i = 0; i < indent * 2; i++) {
    file << " ";
  }

  file << node->type << ":" << node->name << endl;

  for (int i = 0; i < node->childCount; i++) {
    saveTreeHelper(node->children[i], file, indent + 1);
  }
}

void AreaTree::loadTreeFromFile(string filename) {
  ifstream inFile(filename.c_str());

  if (!inFile) {
    return;
  }

  // Clear existing tree if any
  if (root != NULL) {
    root = NULL;
  }

  string line;
  string currentCity = "";
  string currentArea = "";
  int lineNumber = 0;

  while (getline(inFile, line)) {
    lineNumber++;

    // Skip empty lines
    if (line.length() == 0)
      continue;

    // Count leading spaces to determine level
    int spaces = 0;
    for (int i = 0; i < line.length() && line[i] == ' '; i++) {
      spaces++;
    }

    int level = spaces / 2;

    // Find the colon separator
    int colonPos = -1;
    for (int i = spaces; i < line.length(); i++) {
      if (line[i] == ':') {
        colonPos = i;
        break;
      }
    }

    if (colonPos == -1) {
      continue; // Skip malformed lines silently
    }

    string type = line.substr(spaces, colonPos - spaces);
    string name = line.substr(colonPos + 1);

    if (type == "COUNTRY" || type == "Country") {
      if (level != 0) {
        continue;
      }
      createRoot(name);
    } else if (type == "CITY" || type == "City") {
      if (level != 1) {
        continue;
      }
      addCity(name);
      currentCity = name;
    } else if (type == "AREA" || type == "Area") {
      if (level != 2) {
        continue;
      }
      if (currentCity == "") {
        continue;
      }
      addArea(currentCity, name);
      currentArea = name;
    } else if (type == "SENSOR" || type == "Sensor") {
      if (level != 3) {
        continue;
      }
      if (currentCity == "" || currentArea == "") {
        continue;
      }
      string sensorName = name;
      string sensorType = "";

      // Check for 2nd colon (Sensor:Type:Name)
      size_t secondColon = name.find(':');
      if (secondColon != string::npos) {
        sensorType = name.substr(0, secondColon);
        sensorName = name.substr(secondColon + 1);
      } else {
        continue;
      }

      addSensor(currentCity, currentArea, sensorName, sensorType);
    } else {
      // Unknown type, skip silently
      continue;
    }
  }

  inFile.close();
}

PollutionGraph::PollutionGraph() {
  areaCount = 0;

  for (int i = 0; i < MAX_AREAS; i++) {
    for (int j = 0; j < MAX_AREAS; j++) {
      adjacencyMatrix[i][j] = 0;
    }
  }
}

void PollutionGraph::addArea(string name, float pollutionLevel) {
  if (areaCount >= MAX_AREAS) {
    cout << "\nError: Graph is full! Cannot add more areas." << endl;
    return;
  }

  if (name.length() == 0 || name.length() > 50) {
    cout << "\nError: Area name invalid (max 50 chars)!" << endl;
    return;
  }

  areas[areaCount] = Area(areaCount, name, pollutionLevel);
  areaCount++;
  cout << "\nArea '" << name << "' added to graph!" << endl;
}

void PollutionGraph::addConnection(int area1, int area2) {
  if (!areaExists(area1) || !areaExists(area2)) {
    cout << "\nError: One or both areas do not exist!" << endl;
    return;
  }

  if (connectionExists(area1, area2)) {
    cout << "\nError: Connection already exists!" << endl;
    return;
  }

  adjacencyMatrix[area1][area2] = 1;
  adjacencyMatrix[area2][area1] = 1;
  cout << "\nConnection added between " << areas[area1].name << " and "
       << areas[area2].name << endl;
}

void PollutionGraph::displayAreas() {
  if (areaCount == 0) {
    cout << "\nNo areas in graph!" << endl;
    return;
  }

  cout << "\n===== AREAS IN GRAPH =====" << endl;
  for (int i = 0; i < areaCount; i++) {
    cout << "ID: " << areas[i].id << " | Name: " << areas[i].name
         << " | Pollution Level: " << areas[i].pollutionLevel << endl;
  }
  cout << "Total areas: " << areaCount << endl;
  pause();
}

void PollutionGraph::displayConnections() {
  cout << "\n===== AREA CONNECTIONS =====" << endl;
  for (int i = 0; i < areaCount; i++) {
    cout << areas[i].name << " is connected to: ";
    bool hasConnection = false;
    for (int j = 0; j < areaCount; j++) {
      if (adjacencyMatrix[i][j] == 1) {
        cout << areas[j].name << " ";
        hasConnection = true;
      }
    }
    if (!hasConnection) {
      cout << "No connections";
    }
    cout << endl;
  }
}

void PollutionGraph::displayAdjacencyMatrix() {
  cout << "\n===== ADJACENCY MATRIX =====" << endl;
  cout << "   ";
  for (int i = 0; i < areaCount; i++) {
    cout << i << " ";
  }
  cout << endl;

  for (int i = 0; i < areaCount; i++) {
    cout << i << "  ";
    for (int j = 0; j < areaCount; j++) {
      cout << adjacencyMatrix[i][j] << " ";
    }
    cout << endl;
  }
  pause();
}

int PollutionGraph::findAreaByName(string name) {
  for (int i = 0; i < areaCount; i++) {
    if (areas[i].name == name) {
      return i;
    }
  }
  return -1;
}

void PollutionGraph::displayNeighbors(int areaId) {
  if (!areaExists(areaId)) {
    cout << "\nError: Invalid area ID!" << endl;
    return;
  }

  cout << "\n===== NEIGHBORS OF " << areas[areaId].name << " =====" << endl;
  bool hasNeighbor = false;
  for (int i = 0; i < areaCount; i++) {
    if (adjacencyMatrix[areaId][i] == 1) {
      cout << "- " << areas[i].name
           << " (Pollution: " << areas[i].pollutionLevel << ")" << endl;
      hasNeighbor = true;
    }
  }

  if (!hasNeighbor) {
    cout << "No neighbors found!" << endl;
  }
  pause();
}

void PollutionGraph::analyzePollutionSpread(int sourceArea) {
  if (!areaExists(sourceArea)) {
    cout << "\nError: Invalid source area!" << endl;
    return;
  }

  cout << "\n===== POLLUTION SPREAD ANALYSIS =====" << endl;
  cout << "Source: " << areas[sourceArea].name << endl;
  cout << "Pollution Level: " << areas[sourceArea].pollutionLevel << endl;

  cout << "\nAffected neighboring areas:" << endl;
  bool hasAffected = false;

  for (int i = 0; i < areaCount; i++) {
    if (adjacencyMatrix[sourceArea][i] == 1) {
      cout << "- " << areas[i].name << " (Level: " << areas[i].pollutionLevel
           << ")";

      if (areas[sourceArea].pollutionLevel > 75) {
        cout << " - HIGH RISK!";
      }
      cout << endl;
      hasAffected = true;
    }
  }

  if (!hasAffected) {
    cout << "No neighboring areas affected." << endl;
  }
}

void PollutionGraph::findHighlyPollutedAreas() {
  cout << "\n===== HIGHLY POLLUTED AREAS =====" << endl;
  bool found = false;

  for (int i = 0; i < areaCount; i++) {
    if (areas[i].pollutionLevel > 75) {
      cout << "- " << areas[i].name << " (Level: " << areas[i].pollutionLevel
           << ") - CRITICAL!" << endl;
      found = true;
    }
  }

  if (!found) {
    cout << "No highly polluted areas found." << endl;
  }
}

int PollutionGraph::getAreaCount() { return areaCount; }

bool PollutionGraph::areaExists(int areaId) {
  return (areaId >= 0 && areaId < areaCount);
}

bool PollutionGraph::connectionExists(int area1, int area2) {
  return (adjacencyMatrix[area1][area2] == 1);
}

void PollutionGraph::syncAreasFromTree(AreaTree &tree, PollutionList &pList) {
  ifstream inFile("tree_data.txt");

  if (!inFile) {
    cout << "\nError: tree_data.txt file not found!" << endl;
    return;
  }

  areaCount = 0;
  string line;

  while (getline(inFile, line)) {
    if (line.length() == 0)
      continue;

    int spaces = 0;
    for (int i = 0; i < line.length() && line[i] == ' '; i++) {
      spaces++;
    }

    int level = spaces / 2;

    int colonPos = -1;
    for (int i = spaces; i < line.length(); i++) {
      if (line[i] == ':') {
        colonPos = i;
        break;
      }
    }

    if (colonPos == -1)
      continue;

    string type = line.substr(spaces, colonPos - spaces);
    string name = line.substr(colonPos + 1);

    if ((type == "AREA" || type == "Area") && areaCount < MAX_AREAS) {
      float avgPollution = 0.0;
      int count = 0;

      PollutionNode *temp = pList.getHead();
      while (temp != NULL) {
        string pollutionLoc = temp->data.getLocation();
        string areaName = name;

        for (int i = 0; i < pollutionLoc.length(); i++) {
          pollutionLoc[i] = tolower(pollutionLoc[i]);
        }
        for (int i = 0; i < areaName.length(); i++) {
          areaName[i] = tolower(areaName[i]);
        }

        if (pollutionLoc == areaName) {
          avgPollution += temp->data.getValue();
          count++;
        }
        temp = temp->next;
      }

      if (count > 0) {
        avgPollution = avgPollution / count;
      }

      areas[areaCount] = Area(areaCount, name, avgPollution);
      areaCount++;
    }
  }

  inFile.close();
  cout << "\nLoaded " << areaCount
       << " areas from tree_data.txt file with pollution levels!" << endl;
}

FileHandler::FileHandler() {
  pollutionFile = "pollution_data.txt";
  complaintFile = "complaint_data.txt";
  sensorFile = "sensor_data.txt";
}

// Save pollution data to file
void FileHandler::savePollutionData(PollutionList &pList) {
  ofstream outFile(pollutionFile);

  if (!outFile) {
    cout << "\nError: Cannot open file for writing!" << endl;
    return;
  }

  PollutionNode *temp = pList.getHead();
  while (temp != NULL) {
    outFile << temp->data.toString() << endl;
    temp = temp->next;
  }

  outFile.close();
  cout << "\nPollution data saved successfully!" << endl;
}

// Load pollution data from file
void FileHandler::loadPollutionData(PollutionList &pList) {
  ifstream inFile(pollutionFile);

  if (!inFile) {
    cout << "\nNo previous pollution data found." << endl;
    return;
  }

  extern int pollutionIdCounter;
  string line;
  int loaded = 0;

  while (getline(inFile, line)) {
    stringstream ss(line);
    string item;

    int id;
    string country, city, location, type, unit, date;
    float value;
    bool isSafe;

    // Parse CSV line
    getline(ss, item, ',');
    id = stoi(item);

    getline(ss, country, ',');
    getline(ss, city, ',');
    getline(ss, location, ',');
    getline(ss, type, ',');

    getline(ss, item, ',');
    value = stof(item);

    getline(ss, unit, ',');
    getline(ss, date, ',');

    getline(ss, item, ',');
    isSafe = (item == "1");

    Pollution p(id, country, city, location, type, value, unit, date);
    p.setSafeStatus(isSafe);
    pList.addPollution(p);

    if (id >= pollutionIdCounter) {
      pollutionIdCounter = id + 1;
    }
    loaded++;
  }

  inFile.close();
  cout << "\nLoaded " << loaded << " pollution records from file." << endl;
}

// Save complaint data to file
void FileHandler::saveComplaintData(ComplaintList &cList) {
  ofstream outFile(complaintFile);

  if (!outFile) {
    cout << "\nError: Cannot open file for writing!" << endl;
    return;
  }

  ComplaintNode *temp = cList.getHead();
  while (temp != NULL) {
    outFile << temp->data.toString() << endl;
    temp = temp->next;
  }

  outFile.close();
  cout << "\nComplaint data saved successfully!" << endl;
}

// Load complaint data from file
void FileHandler::loadComplaintData(ComplaintList &cList) {
  ifstream inFile(complaintFile);

  if (!inFile) {
    cout << "\nNo previous complaint data found." << endl;
    return;
  }

  extern int complaintIdCounter;
  string line;
  int loaded = 0;

  while (getline(inFile, line)) {
    stringstream ss(line);
    string item;

    int id;
    string name, location, type, description, date, status;

    // Parse CSV line
    getline(ss, item, ',');
    id = stoi(item);

    getline(ss, name, ',');
    getline(ss, location, ',');
    getline(ss, type, ',');
    getline(ss, description, ',');
    getline(ss, date, ',');
    getline(ss, status, ',');

    Complaint c(id, name, location, type, description, date);
    c.setStatus(status);
    cList.addComplaint(c);

    if (id >= complaintIdCounter) {
      complaintIdCounter = id + 1;
    }
    loaded++;
  }

  inFile.close();
  cout << "\nLoaded " << loaded << " complaints from file." << endl;
}

// Save sensor data to file
void FileHandler::saveSensorData(SensorManager &sManager) {
  ofstream outFile(sensorFile);

  if (!outFile) {
    cout << "\nError: Cannot open file for writing!" << endl;
    return;
  }

  for (int i = 0; i < sManager.sensorCount; i++) {
    outFile << sManager.sensors[i].getId() << ","
            << sManager.sensors[i].getType() << ","
            << sManager.sensors[i].getLocation() << ","
            << sManager.sensors[i].getStatus() << ","
            << sManager.sensors[i].getFaultCount() << endl;
  }

  outFile.close();
  cout << "\nSensor data saved successfully!" << endl;
}

// Load sensor data from file
void FileHandler::loadSensorData(SensorManager &sManager) {
  ifstream inFile(sensorFile);

  if (!inFile) {
    cout << "\nNo previous sensor data found." << endl;
    return;
  }

  string line;
  int loaded = 0;

  while (getline(inFile, line) && sManager.sensorCount < 50) {
    stringstream ss(line);
    string idStr, type, location, statusStr, faultCountStr;

    // Parse CSV: id,type,location,status,faultCount
    if (getline(ss, idStr, ',') && getline(ss, type, ',') &&
        getline(ss, location, ',') && getline(ss, statusStr, ',') &&
        getline(ss, faultCountStr, ',')) {

      int id = atoi(idStr.c_str());
      bool status = (statusStr == "1");
      int faultCount = atoi(faultCountStr.c_str());

      // Create sensor and add to manager
      Sensor s(id, type, location);
      if (!status) {
        s.setStatus(false);
      }
      for (int i = 0; i < faultCount; i++) {
        s.incrementFaultCount();
      }

      sManager.sensors[sManager.sensorCount++] = s;

      extern int sensorIdCounter;
      if (id >= sensorIdCounter) {
        sensorIdCounter = id + 1;
      }

      loaded++;
    }
  }

  inFile.close();
  cout << "\nLoaded " << loaded << " sensors from file." << endl;
}

// Check if file exists
bool FileHandler::fileExists(string filename) {
  ifstream file(filename);
  return file.good();
}

// Create backup
void FileHandler::createBackup() {
  cout << "\nCreating backup..." << endl;

  // Simple backup implementation
  ifstream src(pollutionFile);
  ofstream dst("pollution_data_backup.txt");

  if (src && dst) {
    dst << src.rdbuf();
    cout << "Backup created successfully!" << endl;
  }

  src.close();
  dst.close();
}

// ===== MAIN PROGRAM =====

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

/* Global Objects */
PollutionList pollutionList;
ComplaintList complaintList;
SensorManager sensorManager;
SensorQueue sensorQueue;
AreaTree areaTree;
PollutionGraph pollutionGraph;
UndoStack undoStack(50);
FileHandler fileHandler;

/* ID Counters */
int pollutionIdCounter = 1;
int complaintIdCounter = 1;
int sensorIdCounter = 1;

/* Function Prototypes */
void mainMenu();
void pollutionMenu();
void sensorMenu();
void areaTreeMenu();
void graphMenu();
void complaintMenu();
void reportMenu();
void undoMenu();

void clearScreen();
void pause();
void initializeSampleData();

/*MAIN*/
int main() {
  cout << "========================================\n";
  cout << " ENVIRONMENTAL POLLUTION TRACKER SYSTEM\n";
  cout << "========================================\n";

  // Load existing data first
  fileHandler.loadPollutionData(pollutionList);
  fileHandler.loadComplaintData(complaintList);
  fileHandler.loadSensorData(sensorManager);

  // Only initialize sample data if no data was loaded
  if (sensorManager.getSensorCount() == 0) {
    initializeSampleData();
  }

  // Update ID counters based on loaded data to prevent conflicts
  if (complaintList.getCount() > 0) {
    ComplaintNode *temp = complaintList.getHead();
    int maxId = 0;
    while (temp != NULL) {
      if (temp->data.getId() > maxId) {
        maxId = temp->data.getId();
      }
      temp = temp->next;
    }
    complaintIdCounter = maxId + 1;
  }

  // Update sensor ID counter based on loaded sensors
  if (sensorManager.getSensorCount() > 0) {
    int maxId = 0;
    for (int i = 0; i < sensorManager.getSensorCount(); i++) {
      if (sensorManager.sensors[i].getId() > maxId) {
        maxId = sensorManager.sensors[i].getId();
      }
    }
    sensorIdCounter = maxId + 1;
  }

  pause();
  mainMenu();
  return 0;
}

/*MAIN MENU*/
void mainMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Pollution Management";
    cout << "\n2. Sensor Management";
    cout << "\n3. Area Tree";
    cout << "\n4. Pollution Graph";
    cout << "\n5. Complaints";
    cout << "\n6. Reports";
    cout << "\n7. Undo Operations";
    cout << "\n8. Save Data";
    cout << "\n9. Exit";
    cout << "\nChoice: ";
    cin >> choice;

    switch (choice) {
    case 1:
      pollutionMenu();
      break;
    case 2:
      sensorMenu();
      break;
    case 3:
      areaTreeMenu();
      break;
    case 4:
      graphMenu();
      break;
    case 5:
      complaintMenu();
      break;
    case 6:
      reportMenu();
      break;
    case 7:
      undoMenu();
      break;
    case 8:
      cout << "\n========================================" << endl;
      cout << "         SAVING DATA..." << endl;
      cout << "========================================" << endl;
      fileHandler.savePollutionData(pollutionList);
      fileHandler.saveComplaintData(complaintList);
      fileHandler.saveSensorData(sensorManager);
      cout << "\n========================================" << endl;
      cout << "    ALL DATA SAVED SUCCESSFULLY!" << endl;
      cout << "========================================" << endl;
      pause();
      break;
    case 9:
      fileHandler.savePollutionData(pollutionList);
      fileHandler.saveComplaintData(complaintList);
      fileHandler.saveSensorData(sensorManager);
      exit(0);
    default:
      cout << "Invalid choice!";
      pause();
    }
  }
}

/*POLLUTION MENU*/
void pollutionMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Add Record";
    cout << "\n2. View All";
    cout << "\n3. Update Value";
    cout << "\n4. Search by ID";
    cout << "\n5. Delete Record";
    cout << "\n6. Safety Alerts";
    cout << "\n7. Average Per Area";
    cout << "\n8. Predict Pollution";
    cout << "\n9. Trend Analysis";
    cout << "\n10. Filter by Type";
    cout << "\n11. Filter by Location";
    cout << "\n12. Severity Distribution";
    cout << "\n13. Unsafe Records Count";
    cout << "\n14. Sort by Value";
    cout << "\n15. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 15)
      return;

    switch (choice) {
    case 1: {
      string country, city, location, type, unit, date;
      float value;

      PollutionNode *tempSync = pollutionList.getHead();
      while (tempSync != NULL) {
        if (tempSync->data.getId() >= pollutionIdCounter) {
          pollutionIdCounter = tempSync->data.getId() + 1;
        }
        tempSync = tempSync->next;
      }

      cin.ignore();
      cout << "Country: ";
      getline(cin, country);
      cout << "City: ";
      getline(cin, city);
      cout << "Location/Area: ";
      getline(cin, location);
      cout << "Type: ";
      getline(cin, type);
      cout << "Value: ";
      cin >> value;
      cin.ignore();
      cout << "Unit: ";
      getline(cin, unit);
      cout << "Date: ";
      getline(cin, date);

      Pollution p(pollutionIdCounter++, country, city, location, type, value,
                  unit, date);
      pollutionList.addPollution(p);
      undoStack.push(Operation("ADD_POLLUTION", p.getId(), "Add", date));
      pause();
      break;
    }
    case 2:
      pollutionList.displayAll();
      pause();
      break;
    case 3: {
      int id;
      float newValue;
      cout << "Enter Pollution ID: ";
      cin >> id;
      cout << "Enter New Value: ";
      cin >> newValue;
      pollutionList.updatePollutionValue(id, newValue);
      pause();
      break;
    }
    case 4: {
      int id;
      cout << "ID: ";
      cin >> id;
      Pollution *p = pollutionList.searchById(id);
      if (p)
        p->display();
      else
        cout << "Not found";
      pause();
      break;
    }
    case 5: {
      int id;
      cout << "ID: ";
      cin >> id;
      pollutionList.deleteById(id);
      undoStack.push(Operation("DELETE_POLLUTION", id, "Delete", ""));
      pause();
      break;
    }
    case 6:
      pollutionList.checkSafetyAlerts();
      pause();
      break;
    case 7:
      pollutionList.displayAveragePollutionPerArea();
      pause();
      break;

    case 8:
      pollutionList.predictPollution();
      pause();
      break;
    case 9:
      pollutionList.trendAnalysis();
      pause();
      break;
    case 10: {
      string type;
      cin.ignore();
      cout << "Enter Pollution Type (Air/Water/Soil/Noise): ";
      getline(cin, type);
      pollutionList.displayByType(type);
      pause();
      break;
    }
    case 11: {
      string location;
      cin.ignore();
      cout << "Enter Location: ";
      getline(cin, location);
      pollutionList.displayByLocation(location);
      pause();
      break;
    }
    case 12:
      pollutionList.displaySeverityDistribution();
      pause();
      break;
    case 13:
      pollutionList.countUnsafeRecords();
      pause();
      break;
    case 14:
      pollutionList.sortByValue();
      pollutionList.displayAll();
      pause();
      break;
    default:
      cout << "Invalid choice";
      pause();
    }
  }
}

/* ================= SENSOR MENU ================= */
// External declaration for area tree integration
extern AreaTree areaTree;

void sensorMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Add Sensor";
    cout << "\n2. View All";
    cout << "\n3. Toggle Status";
    cout << "\n4. Simulate Readings";
    cout << "\n5. Add to Queue";
    cout << "\n6. Process Queue";
    cout << "\n7. View Active Only";
    cout << "\n8. View Inactive Only";
    cout << "\n9. Deactivate Faulty";
    cout << "\n10. Reset Sensor Health";
    cout << "\n11. Emergency Shutdown";
    cout << "\n12. Manual Data Entry";
    cout << "\n13. Count Active in Area";
    cout << "\n14. Count Faulty Sensors";
    cout << "\n15. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 15)
      return;

    switch (choice) {
    case 1: {
      for (int i = 0; i < sensorManager.sensorCount; i++) {
        if (sensorManager.sensors[i].getId() >= sensorIdCounter) {
          sensorIdCounter = sensorManager.sensors[i].getId() + 1;
        }
      }
      string type, city, area, sensorName;
      cin.ignore();
      cout << "City Name: ";
      getline(cin, city);
      cout << "Area Name: ";
      getline(cin, area);
      cout << "Sensor Name: ";
      getline(cin, sensorName);
      cout << "Type (Air/Water/Soil/Noise): ";
      getline(cin, type);

      // Validate that city and area exist in tree
      if (areaTree.findArea(city, area) == NULL) {
        cout << "\nError: City/Area not found in Area Tree!" << endl;
        cout << "Please add the city and area to the tree first." << endl;
        pause();
        break;
      }

      // Add to both systems
      areaTree.addSensor(city, area, sensorName, type);

      // Record operation for undo
      undoStack.push(Operation("ADD_SENSOR", sensorIdCounter - 1, "Add", ""));

      pause();
      break;
    }
    case 2:
      sensorManager.displayAllSensors();
      pause();
      break;
    case 3: {
      int id;
      cout << "Sensor ID: ";
      cin >> id;
      sensorManager.toggleSensorStatus(id);
      pause();
      break;
    }
    case 4:
      sensorManager.simulateAllReadings();
      pause();
      break;
    case 5: {
      int id;
      cout << "Sensor ID: ";
      cin >> id;
      Sensor *s = sensorManager.findSensorById(id);
      if (s) {
        sensorQueue.enqueue(*s);
        cout << "\nSensor " << id << " added to queue successfully!" << endl;
      } else {
        cout << "\nError: Sensor ID " << id << " not found!" << endl;
      }
      pause();
      break;
    }
    case 6:
      sensorQueue.processAllSensors();
      pause();
      break;
    case 7:
      sensorManager.displayActiveSensors();
      pause();
      break;
    case 8:
      sensorManager.displayInactiveSensors();
      pause();
      break;
    case 9:
      sensorManager.deactivateFaultySensors();
      pause();
      break;
    case 10: {
      int id;
      cout << "Enter Sensor ID: ";
      cin >> id;
      sensorManager.resetSensorHealth(id);
      pause();
      break;
    }
    case 11: {
      string area;
      cin.ignore();
      cout << "Enter Area Name: ";
      getline(cin, area);
      sensorManager.emergencyShutdownByArea(area);
      pause();
      break;
    }
    case 12:
      sensorManager.manualDataEntry();
      pause();
      break;
    case 13: {
      string area;
      cin.ignore();
      cout << "Enter Area Name: ";
      getline(cin, area);
      int count = sensorManager.countActiveInArea(area);
      cout << "\nActive sensors in " << area << ": " << count << endl;
      pause();
      break;
    }
    case 14: {
      int count = sensorManager.countFaultySensors();
      cout << "\nTotal faulty sensors: " << count << endl;
      pause();
      break;
    }
    default:
      cout << "Invalid";
      pause();
    }
  }
}

/* ================= COMPLAINT MENU ================= */
void complaintMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Add Complaint";
    cout << "\n2. View All";
    cout << "\n3. Update Status";
    cout << "\n4. View Pending";
    cout << "\n5. View Resolved";
    cout << "\n6. Filter by Type";
    cout << "\n7. Filter by Location";
    cout << "\n8. Quick Resolve";
    cout << "\n9. Resolution Stats";
    cout << "\n10. Type Distribution";
    cout << "\n11. Sort by Date";
    cout << "\n12. Search by ID";
    cout << "\n13. Recalculate Priorities";
    cout << "\n14. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 14)
      return;

    switch (choice) {
    case 1: {
      ComplaintNode *tempSync = complaintList.getHead();
      while (tempSync != NULL) {
        if (tempSync->data.getId() >= complaintIdCounter) {
          complaintIdCounter = tempSync->data.getId() + 1;
        }
        tempSync = tempSync->next;
      }
      string name, location, type, desc, date;
      cin.ignore();
      cout << "Name: ";
      getline(cin, name);
      cout << "Location: ";
      getline(cin, location);
      cout << "Type: ";
      getline(cin, type);
      cout << "Description: ";
      getline(cin, desc);
      cout << "Date: ";
      getline(cin, date);

      Complaint c(complaintIdCounter++, name, location, type, desc, date);
      complaintList.addComplaint(c);
      undoStack.push(Operation("ADD_COMPLAINT", c.getId(), "Add", date));

      // Auto-save after adding complaint
      fileHandler.saveComplaintData(complaintList);

      pause();
      break;
    }
    case 2:
      complaintList.displayAll();
      break;
    case 3: {
      int id;
      string status;
      cout << "ID: ";
      cin >> id;
      cin.ignore();
      cout << "Status: ";
      getline(cin, status);
      complaintList.updateStatus(id, status);
      pause();
      break;
    }
    case 4:
      complaintList.displayPending();
      pause();
      break;
    case 5:
      complaintList.displayResolved();
      pause();
      break;
    case 6: {
      string type;
      cin.ignore();
      cout << "Enter Type (Air/Water/Soil/Noise): ";
      getline(cin, type);
      complaintList.displayByType(type);
      pause();
      break;
    }
    case 7: {
      string location;
      cin.ignore();
      cout << "Enter Location: ";
      getline(cin, location);
      complaintList.displayByLocation(location);
      pause();
      break;
    }
    case 8: {
      int id;
      cout << "Enter Complaint ID to Resolve: ";
      cin >> id;
      complaintList.resolveComplaint(id);
      pause();
      break;
    }
    case 9:
      complaintList.displayResolutionStats();
      pause();
      break;
    case 10:
      complaintList.displayTypeDistribution();
      pause();
      break;
    case 11:
      complaintList.sortByDate();
      complaintList.displayAll();
      break;
    case 12: {
      int id;
      cout << "Enter Complaint ID: ";
      cin >> id;
      Complaint *c = complaintList.searchById(id);
      if (c)
        c->display();
      else
        cout << "\nComplaint not found!" << endl;
      pause();
      break;
    }
    case 13:
      cout << "\nRecalculating priorities based on complaint density..."
           << endl;
      complaintList.calculateAutoPriority();
      cout << "Priorities updated successfully!" << endl;
      pause();
      break;
    default:
      cout << "Invalid";
      pause();
    }
  }
}

/* ================= UNDO MENU ================= */
void undoMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. View History";
    cout << "\n2. Undo Last";
    cout << "\n3. Clear";
    cout << "\n4. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 4)
      return;

    switch (choice) {
    case 1:
      undoStack.displayStack();
      pause();
      break;
    case 2:
      if (!undoStack.isEmpty()) {
        Operation op = undoStack.pop();
        if (op.operationType == "ADD_POLLUTION")
          pollutionList.deleteById(op.recordId);
        else if (op.operationType == "ADD_COMPLAINT")
          complaintList.deleteComplaint(op.recordId);
      }
      pause();
      break;
    case 3:
      undoStack.clear();
      pause();
      break;
    default:
      cout << "Invalid";
      pause();
    }
  }
}

/* ================= HELPERS ================= */
void clearScreen() {
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

void pause() {
  cout << "\nPress Enter to continue...";
  // Clear any leftover input
  cin.clear();
  cin.ignore(numeric_limits<streamsize>::max(), '\n');
  // Wait for Enter
  cin.get();
}

// ===== MENU FUNCTIONS =====

void areaTreeMenu() {
  // Auto-load tree from file on first access
  static bool treeLoaded = false;
  if (!treeLoaded) {
    areaTree.loadTreeFromFile("tree_data.txt");
    treeLoaded = true;
  }

  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Create Root Country";
    cout << "\n2. Add City";
    cout << "\n3. Add Area";
    cout << "\n4. Add Sensor";
    cout << "\n5. Display Tree";
    cout << "\n6. Display City Areas";
    cout << "\n7. Display Area Sensors";
    cout << "\n8. Save Tree to File";
    cout << "\n9. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 9)
      return;

    switch (choice) {
    case 1: {
      string country;
      cin.ignore();
      cout << "Country Name: ";
      getline(cin, country);
      areaTree.createRoot(country);
      pause();
      break;
    }
    case 2: {
      string city;
      cin.ignore();
      cout << "City Name: ";
      getline(cin, city);
      areaTree.addCity(city);
      pause();
      break;
    }
    case 3: {
      string city, area;
      cin.ignore();
      cout << "City Name: ";
      getline(cin, city);
      cout << "Area Name: ";
      getline(cin, area);
      areaTree.addArea(city, area);
      pause();
      break;
    }
    case 4: {
      string city, area, sensor, sensorType;
      cin.ignore();
      cout << "City Name: ";
      getline(cin, city);
      cout << "Area Name: ";
      getline(cin, area);
      cout << "Sensor Name: ";
      getline(cin, sensor);
      cout << "Sensor Type (Air/Water/Soil/Noise): ";
      getline(cin, sensorType);
      areaTree.addSensor(city, area, sensor, sensorType);
      pause();
      break;
    }
    case 5:
      areaTree.displayTree();
      break;
    case 6: {
      string city;
      cin.ignore();
      cout << "Enter City Name: ";
      getline(cin, city);
      areaTree.displayAreas(city);
      break;
    }
    case 7: {
      string city, area;
      cin.ignore();
      cout << "Enter City Name: ";
      getline(cin, city);
      cout << "Enter Area Name: ";
      getline(cin, area);
      areaTree.displaySensors(city, area);
      pause();
      break;
    }
    case 8:
      areaTree.saveTreeToFile("tree_data.txt");
      pause();
      break;
    default:
      cout << "Invalid choice";
      pause();
    }
  }
}

void graphMenu() {
  static bool areasLoaded = false;
  if (!areasLoaded) {
    pollutionGraph.syncAreasFromTree(areaTree, pollutionList);
    areasLoaded = true;
  }

  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Sync Areas from Tree";
    cout << "\n2. Add Connection";
    cout << "\n3. Display Areas";
    cout << "\n4. Display Connections";
    cout << "\n5. Pollution Spread Analysis";
    cout << "\n6. Find Highly Polluted";
    cout << "\n7. Display Neighbors";
    cout << "\n8. Adjacency Matrix";
    cout << "\n9. Find Area by Name";
    cout << "\n10. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 10)
      return;

    switch (choice) {
    case 1:
      pollutionGraph.syncAreasFromTree(areaTree, pollutionList);
      pause();
      break;
    case 2: {
      int area1, area2;
      cout << "Area 1 ID: ";
      cin >> area1;
      cout << "Area 2 ID: ";
      cin >> area2;
      pollutionGraph.addConnection(area1, area2);
      pause();
      break;
    }
    case 3:
      pollutionGraph.displayAreas();
      pause();
      break;
    case 4:
      pollutionGraph.displayConnections();
      pause();
      break;
    case 5: {
      int source;
      cout << "Enter Source Area ID: ";
      cin >> source;
      pollutionGraph.analyzePollutionSpread(source);
      pause();
      break;
    }
    case 6:
      pollutionGraph.findHighlyPollutedAreas();
      pause();
      break;
    case 7: {
      int areaId;
      cout << "Enter Area ID: ";
      cin >> areaId;
      pollutionGraph.displayNeighbors(areaId);
      pause();
      break;
    }
    case 8:
      pollutionGraph.displayAdjacencyMatrix();
      pause();
      break;
    case 9: {
      string name;
      cin.ignore();
      cout << "Enter Area Name: ";
      getline(cin, name);
      int id = pollutionGraph.findAreaByName(name);
      if (id != -1)
        cout << "\nArea '" << name << "' found with ID: " << id << endl;
      else
        cout << "\nArea not found!" << endl;
      pause();
      break;
    }
    default:
      cout << "Invalid choice";
      pause();
    }
  }
}

void reportMenu() {
  int choice;
  while (true) {
    clearScreen();
    cout << "\n1. Pollution Report";
    cout << "\n2. Complaint Statistics";
    cout << "\n3. Safety Alerts";
    cout << "\n4. Trend Report";
    cout << "\n5. Back";
    cout << "\nChoice: ";
    cin >> choice;

    if (choice == 5)
      return;

    switch (choice) {
    case 1:
      pollutionList.generateReport();
      pause();
      break;
    case 2:
      complaintList.displayResolutionStats();
      complaintList.displayTypeDistribution();
      pause();
      break;
    case 3:
      pollutionList.checkSafetyAlerts();
      pause();
      break;
    case 4:
      pollutionList.displayTrendReport();
      pause();
      break;
    default:
      cout << "Invalid choice";
      pause();
    }
  }
}

void initializeSampleData() {
  // Auto-load tree from file if it exists
  areaTree.loadTreeFromFile("tree_data.txt");

  // Keep sensor and pollution sample data
  // sensorManager.addSensor(Sensor(sensorIdCounter++, "Air", "Model Town"));
  // pollutionList.addPollution(Pollution(pollutionIdCounter++, "Pakistan",
  //                                      "Lahore", "Model Town", "Air", 85,
  //                                      "PM2.5", "12-12-2025"));
}
